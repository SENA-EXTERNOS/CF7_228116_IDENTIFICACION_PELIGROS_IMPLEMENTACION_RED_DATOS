function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5eZoYmzKInF":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

